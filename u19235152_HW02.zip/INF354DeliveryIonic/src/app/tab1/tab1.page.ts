import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
//import the sharedModels folder
import { ListOfRestaurants } from '../shared/restaurantList';
import { CommonModule, JsonPipe } from '@angular/common';
import { rCart } from '../shared/rCart';


@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  //standalone: true,
  //imports: [IonicModule, ExploreContainerComponent, CommonModule],
})
export class Tab1Page {
  //declare a container to hold the list of restaurants objects that will be created
//set to nothing first
  RestaurantList: ListOfRestaurants[]=[];
  //RCart: rCart = new rCart();
  RCart!: rCart;

  constructor() {}



//when page loads we need to acces the storage. Access using keys
//the restuarant must have persistent data such as your:
//name, type of dish, ratings, distance to home/school address,and price
//this is where class manipulation come in=>through the RestuarantList.ts file

ngOnInit()
{
    //convert to JS object
    //the ! means it can be null or indefined
    //we try to convert into localStorage of the name of the restaurant

    this.RestaurantList = JSON.parse(localStorage.getItem('ResturantList')!);
    this.RCart = JSON.parse(localStorage.getItem('RCart')!);
    //we check for the length
    if(this.RestaurantList == null)
    {
      this.myRestaurantDb();
    }
    this.cartCheck();
}

  myRestaurantDb()
  {
    this.RestaurantList = [];
    
    let rest1 = new ListOfRestaurants();
        rest1.rId = 1;
        rest1.rImage = "../../assets/R_Images/F_image.jpg";
        rest1.rName = "Farenheit";
        rest1.rTypeOfDish = "Seafood";
        rest1.rRatings = 4.4;
        rest1.rTravelTime = 15;
        rest1.rPrice = 350;
        rest1.rHomeDistance = 16;
    this.RestaurantList.push(rest1);

    let rest2 = new ListOfRestaurants();
        rest2.rId = 2;
        rest2.rImage = "../../assets/R_Images/vs_image.jpg";
        rest2.rName = "The Victrorian Secret";
        rest2.rTypeOfDish = "French patisserie, High Tea";
        rest2.rRatings = 4.4;
        rest2.rTravelTime = 14;
        rest2.rPrice = 150;
        rest2.rHomeDistance = 15.7;
    this.RestaurantList.push(rest2);
   
    let rest3 = new ListOfRestaurants();
        rest3.rId = 3;
        rest3.rImage = "../../assets/R_Images/c_image.jpg";
        rest3.rName = "Ciello";
        rest3.rTypeOfDish = "Mediterranean Cuisine";
        rest3.rRatings = 3.5;
        rest3.rTravelTime = 13;
        rest3.rPrice = 250;
        rest3.rHomeDistance = 7.9;
    this.RestaurantList.push(rest3);

    let rest4 = new ListOfRestaurants();
        rest4.rId = 4;
        rest4.rImage = "../../assets/R_Images/spur_image.jpeg";
        rest4.rName = "Spur";
        rest4.rTypeOfDish = "BBQ Grill";
        rest4.rRatings = 4.0;
        rest4.rTravelTime = 15;
        rest4.rPrice = 205;
        rest4.rHomeDistance = 1.36;
    this.RestaurantList.push(rest4);

    //want to write our data into localstorage 
    localStorage.setItem('RestaurantList', JSON.stringify(this.RestaurantList));

  }

  //in order to fix our logic break
  cartCheck(){
    if(this.RCart == null)
    {
      //if the cart does not exist, initialise new cart
      this.RCart = new rCart();
    }

    //this.RCart = JSON.parse(localStorage.getItem('RCart')!);
  }



  //When you click on the restaurant on the home page, it should automatically create “one” order for you in the 
  //Cart tab
  //need an onclick function for cart
  //declare a function

  cartTabAdd(reso: ListOfRestaurants){
    //if there is something in cart
    //so need to write into localStorage
    //we need to structure our info so we create a new class file in Shared folder
    
    //this.RCart = JSON.parse(localStorage.getItem('RCart')!);
    
    //array in roder to hold the cart items
    //let existingCItems= [];

    //iff there is a cart
    /*if(this.RCart == null)
    {
      //if the cart does not exist, initialise new cart
      this.RCart = new rCart();
    }*/
    if(this.RCart.ListOfRestaurants != null)
    {
      if(this.RCart.ListOfRestaurants.rId == reso.rId){
        this.RCart.ListOfRestaurants.orderquantity = this.RCart.ListOfRestaurants.orderquantity + 1;
        this.saveToCart();
      }
          
    }
    else
    {
        reso.orderquantity = 1; 
        this.RCart.ListOfRestaurants = reso;
        this.saveToCart();
    }  
    }
    //see if the cart tab has the restuarant items in it first
   

saveToCart()
{
  localStorage.removeItem('RCart');
  localStorage.setItem('RCart',JSON.stringify(this.RCart));
}
  //create the cart then



}

