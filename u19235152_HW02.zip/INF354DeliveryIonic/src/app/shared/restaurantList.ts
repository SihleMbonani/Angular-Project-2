export class ListOfRestaurants {
    rId : number = 0;
    rImage : string = "";
    rName!: string;
    rTypeOfDish: string = "";
    rRatings: number = 0;
    rTravelTime: number =0;
    rPrice: number = 0;
    rHomeDistance: number = 0;
    orderquantity:number = 0;
    delFee: number = 50;
}
/*image , name, 
type of dish, ratings, distance to home/school address,
 and price*/
//This is where we fill in the necesaary data for our restuarants