import { ListOfRestaurants } from "./restaurantList";

// export class L_order{
//     restaurant: ListOfRestaurants = new ListOfRestaurants();
//     quantityL: number = 0;
//     resId: number=0;
// }
export class rCart{
    //array of restaurant data type
// lOrders: ListOfRestaurants[] = [];
    //info to show in the cart
    // myRTotals! : number;
    ListOfRestaurants!: ListOfRestaurants;
}