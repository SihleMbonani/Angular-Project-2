import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ListOfRestaurants } from '../shared/restaurantList';
//import { ReactiveFormsModule } from '@angular/forms';
import {rCart } from '../shared/rCart';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  //standalone: true,
  //imports: [ IonicModule, FormsModule, CommonModule, BrowserModule, ReactiveFormsModule],
})
export class Tab2Page {
  rSearch: string= "";
  RestaurantList: ListOfRestaurants[] = [];
  foundedRestaurant: ListOfRestaurants[] = [];
  RCart!: rCart;

  constructor() {
  }

  Search(){
    //const rSearch = this.rSearch.valueChanges;
    //filter out the list of restaurants we have in Home

    //first clear out what is there
    this.foundedRestaurant = [];
    //loop through all of my restaurant and find the keys
    //filter thru the list, search only by the name of restaurant
    //put in lowercase in order to standardise the search
    this.foundedRestaurant = this.RestaurantList.filter(
      (rsItem) => rsItem.rName.toLowerCase().includes(this.rSearch.toLowerCase())
      || rsItem.rTypeOfDish.toLowerCase().includes(this.rSearch.toLowerCase())
      || rsItem.rRatings== Number(this.rSearch.toLowerCase()) //because it is a number parseInt or Number(when there is a decimal or as it is)
      || rsItem.rPrice== Number(this.rSearch.toLowerCase())
      || rsItem.rHomeDistance == Number(this.rSearch.toLowerCase())
      
    );
      //can now also be conditional in order to: 
      /*search for any of the restaurants from the home page along with the name, 
      //type of dish, ratings, distance to home/school addres*/

  }

  ngOnInit(){
    this.RestaurantList = JSON.parse(localStorage.getItem('ResturantList')!);
    this.RCart = JSON.parse(localStorage.getItem('RCart')!);
    if(this.rSearch == ""){
      this.foundedRestaurant = this.RestaurantList;
    }
  }
 //When you click on the restaurant in the search tab, it should automatically create “one” order for you in the 
//Cart tab.  
  cartTabAdd(reso:ListOfRestaurants){
    //if there is something in cart
    //so need to write into localStorage
    //we need to structure our info so we create a new class file in Shared folder
    
    //this.RCart = JSON.parse(localStorage.getItem('RCart')!);
    
    //array in roder to hold the cart items
    //let existingCItems= [];

    //iff there is a cart
    /*if(this.RCart == null)
    {
      //if the cart does not exist, initialise new cart
      this.RCart = new rCart();
    }*/

    //see if the cart tab has the restuarant items in it first
    if(this.RCart.ListOfRestaurants != null)
    {
      if(this.RCart.ListOfRestaurants.rId == reso.rId){
        this.RCart.ListOfRestaurants.orderquantity = this.RCart.ListOfRestaurants.orderquantity + 1;
        this.saveToCart();
      }
          
    }
    else
    {
        reso.orderquantity = 1; 
        this.RCart.ListOfRestaurants = reso;
        this.saveToCart();
    }  
  }
      //console.log(rItemAdd);
      //also respectively
      // if(rItemAdd == true)
      // {
      //   let newL_order = new L_order(); 
      //   newL_order.resId = reso.rId;
      //   newL_order.restaurant = reso;
      //   //know its one because its the the first one we are getting
      //   newL_order.quantityL = 1;

      //   //push item to the current cart
      //   this.RCart.lOrders.push(newL_order);
      // }


  saveToCart()
  {
    localStorage.removeItem('RCart');
    localStorage.setItem('RCart',JSON.stringify(this.RCart));
  }
}

