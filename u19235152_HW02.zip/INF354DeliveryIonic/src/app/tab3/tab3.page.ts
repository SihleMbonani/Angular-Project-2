import { Component } from '@angular/core';
import { rCart } from '../shared/rCart';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  RCart!: rCart;
  constructor() {}

  ngOnInit(){
    //this.RestaurantList = JSON.parse(localStorage.getItem('ResturantList')!);
    this.RCart = JSON.parse(localStorage.getItem('RCart')!);
    
  }
}
